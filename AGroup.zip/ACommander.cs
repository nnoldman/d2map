﻿using UnityEngine;
using System.Collections;
using System;

public class ACommander : Trun
{
}

public class ACommanderRetreat : ACommander
{

}

public class ACommanderFindEnemy : ACommander
{

}

public class ACommanderAttack : ACommander
{

}

public class ACommanderSurround : ACommander
{

}

public class ACommanderBreakOut : ACommander
{

}