﻿using UnityEngine;
using System.Collections;

public class AUnit : MonoBehaviour {
    
    public APathAgent formationPosition;

    ACommander mCurCommander;

    public virtual void Execute(ACommander commander)
    {

    }
}
