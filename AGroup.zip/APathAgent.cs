﻿using UnityEngine;
using System.Collections;

public class APathAgent : MonoBehaviour
{
    public void SetPostion(APostion pos)
    {

    }

    public void MoveToPostion(APostion pos)
    {

    }
}
