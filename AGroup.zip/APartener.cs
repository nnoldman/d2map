﻿using UnityEngine;
using System.Collections;

public class APartener : AUnit {
}
