﻿using UnityEngine;
using System.Collections;

public class APostion 
{
    public int x;
    public int y;
}
